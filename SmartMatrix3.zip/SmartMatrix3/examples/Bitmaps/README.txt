This sketch demonstrates how to compile a bitmap into your Arduino sketch and load it into the display buffer.  More details on this feature are at:  
http://docs.pixelmatix.com/SmartMatrix/library.html#drawing-raw-bitmaps
